#include "Line.hpp"

#include <cmath>

Line::Line(Vector<double> position, Vector<double> direction_cosines) :
    position(position)
{
    m = Vector<double>(direction_cosines.x,
	       direction_cosines.y,
	       direction_cosines.z);
}

bool Line::intersects_with(Vector<double> plane)
{
    if (plane.x != 0)  return m.x != 0;
    if (plane.y != 0)  return m.y != 0;
    if (plane.z != 0)  return m.z != 0;
    return false;
}

Vector<double> Line::intersection(Vector<double> plane)
{
    Vector<double> intersection;
    if (plane.x != 0)
    {
	double t = (plane.x - position.x) / m.x;
	intersection.x = plane.x;
	intersection.y = position.y + t * m.y;
	intersection.z = position.z + t * m.z;
    }
    if (plane.y != 0)
    {
	double t = (plane.y - position.y) / m.y;
	intersection.y = plane.y;
	intersection.x = position.x + t * m.x;
	intersection.z = position.z + t * m.z;
    }
    if (plane.z != 0)
    {
	double t = (plane.z - position.z) / m.z;
	intersection.z = plane.z;
	intersection.y = position.y + t * m.y;
	intersection.x = position.x + t * m.x;
    }


    return intersection;	
}

