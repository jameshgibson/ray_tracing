#pragma once

#include "Vector.hpp"

class Line
{
public:

    Line() {}
    Line(Vector<double> position, Vector<double> direction_cosines);
    bool intersects_with(Vector<double> plane);
    Vector<double> intersection(Vector<double> plane);

private:

    Vector<double> position;
    Vector<double> m;
};
